#!/bin/sh

## new things from Dominus
set -e
OPT=' -arch i386 -m32 -O2 -msse -msse2 -force_cpusubtype_ALL '
SDK=' -mmacosx-version-min=10.6 '
export MACOSX_DEPLOYMENT_TARGET=10.6
export PATH=/opt/local/bin/:/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin
export CC="/Applications/Xcode.app/Contents/Developer/usr/bin/gcc -arch i386"
export CXX="/Applications/Xcode.app/Contents/Developer/usr/bin/g++ -arch i386"
export CPPFLAGS='-I/opt/local/include '$SDK
export CFLAGS='-I/opt/local/include '$SDK' '$OPT
export CXXFLAGS='-I/opt/local/include '$SDK' '$OPT
# export LDFLAGS='-L/opt/local/lib '$SDK' '$OPT  # <- NB commented out
export PKG_CONFIG_PATH="/opt/local/lib/pkgconfig"

./autogen.sh 

./configure --prefix=/opt/dosbox/bin/dosbox --with-sdl-prefix=/opt/dosbox/bin/sdl/ --disable-sdltest --disable-alsatest

make clean 

sed -i.old -e "s@-L/opt/dosbox/bin/sdl/lib -lSDLmain -lSDL -Wl,-framework,Cocoa@-L/opt/dosbox/bin/sdl/lib /opt/dosbox/bin/sdl/lib/libSDLmain.a /opt/dosbox/bin/sdl/lib/libSDL.a -Wl,-framework,OpenGL -Wl,-framework,Cocoa -Wl,-framework,ApplicationServices -Wl,-framework,Carbon -Wl,-framework,AudioToolbox -Wl,-framework,AudioUnit -Wl,-framework,IOKit@g" Makefile

cd src

sed -i.old -e "s@-L/opt/dosbox/bin/sdl/lib -lSDLmain -lSDL -Wl,-framework,Cocoa@-L/opt/dosbox/bin/sdl/lib /opt/dosbox/bin/sdl/lib/libSDLmain.a /opt/dosbox/bin/sdl/lib/libSDL.a -Wl,-framework,OpenGL -Wl,-framework,Cocoa -Wl,-framework,ApplicationServices -Wl,-framework,Carbon -Wl,-framework,AudioToolbox -Wl,-framework,AudioUnit -Wl,-framework,IOKit@g" Makefile

cd ..
make
make install